Ziply compatibility fixture
